clc
clear all

% Antoine constants for Water and Ethanol
A_water = 8.07131;
B_water = 1730.63;
C_water = 233.426;

A_ethanol = 8.2133;
B_ethanol = 1652.05;
C_ethanol = 231.48;

P_total = 760;

T_water_bp = 100;
T_ethanol_bp = 78.23;

T_range = linspace(T_ethanol_bp, T_water_bp, 100);

x_ethanol = linspace(0, 1, 100); % Liquid mole fraction of ethanol
y_ethanol = zeros(size(x_ethanol)); % Vapor mole fraction of ethanol
T_values_ethanol = zeros(size(x_ethanol));
T_values_water = zeros(size(x_ethanol));

% Compute T-x-y diagram
for i = 1:length(x_ethanol)
    x1 = x_ethanol(i);
    x2 = 1 - x1;

    T = fzero(@(T) (x1 * 10^(A_ethanol - B_ethanol / (C_ethanol + T)) + ...
                    x2 * 10^(A_water - B_water / (C_water + T)) - P_total), T_ethanol_bp);
    T_values_ethanol(i) = T;

    P_ethanol = 10^(A_ethanol - B_ethanol / (C_ethanol + T));
    P_water = 10^(A_water - B_water / (C_water + T));

    y_ethanol(i) = (x1 * P_ethanol) / (x1 * P_ethanol + x2 * P_water);
    
    T_values_water(i) = T;
end

% Plot T-x-y diagram
figure;
plot(x_ethanol, T_values_ethanol, 'b-');
hold on;
plot(y_ethanol, T_values_ethanol, 'r--');
plot(x_ethanol, T_values_water, 'g-.');
xlabel('Mole Fraction of Ethanol/Water');
ylabel('Temperature (°C)');
legend('Liquid Ethanol (x)', 'Vapor Ethanol (y)', 'Liquid Water');
title('T-x-y Diagram for Ethanol-Water System at 1 atm');
grid on;

% X-y diagram for ethanol at total pressure of 1 atm
x_y_ethanol = linspace(0, 1, 100);
y_ethanol_x_y = zeros(size(x_y_ethanol));

for i = 1:length(x_y_ethanol)
    x1 = x_y_ethanol(i);
    x2 = 1 - x1;

    T = fzero(@(T) (x1 * 10^(A_ethanol - B_ethanol / (C_ethanol + T)) + ...
                    x2 * 10^(A_water - B_water / (C_water + T)) - P_total), T_ethanol_bp);

    P_ethanol = 10^(A_ethanol - B_ethanol / (C_ethanol + T));
    P_water = 10^(A_water - B_water / (C_water + T));

    y_ethanol_x_y(i) = (x1 * P_ethanol) / (x1 * P_ethanol + x2 * P_water);
end

% Plot x-y diagram
figure;
plot(x_y_ethanol, y_ethanol_x_y, 'g-');
xlabel('Liquid Mole Fraction of Ethanol (x)');
ylabel('Vapor Mole Fraction of Ethanol (y)');
title('X-Y Diagram for Ethanol at Total Pressure of 1 atm');
grid on;

% P-x-y diagram for water at T = 50°C
T_fixed = 50;
P_ethanol = 10^(A_ethanol - B_ethanol / (C_ethanol + T_fixed));
P_water = 10^(A_water - B_water / (C_water + T_fixed));

P_total_range = zeros(size(x_ethanol));
y_water_P = zeros(size(x_ethanol));

for i = 1:length(x_ethanol)
    x2 = x_ethanol(i);
    x1 = 1 - x2;

    P_total_range(i) = x1 * P_ethanol + x2 * P_water;

    y_water_P(i) = (x2 * P_water) / P_total_range(i);
end

% Plot P-x-y diagram
figure;
plot(x_ethanol, P_total_range / P_total, 'b-');
hold on;
plot(y_water_P, P_total_range / P_total, 'r--');
xlabel('Mole Fraction of Water');
ylabel('Total Pressure (atm)');
legend('Liquid (x)', 'Vapor (y)');
title('P-x-y Diagram for Water at T = 50°C');
grid on;
