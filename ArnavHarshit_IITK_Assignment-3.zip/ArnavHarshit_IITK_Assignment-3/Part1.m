clear all;
clc;

x_data = [0, 0.02, 0.04, 0.06, 0.08, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 0.95, 1.0];
y_data = [0, 0.134, 0.23, 0.304, 0.365, 0.418, 0.579, 0.665, 0.729, 0.779, 0.825, 0.87, 0.915, 0.958, 0.979, 1.0];

% y = ax / (1 + bx + cx^2)
model = @(params, x) (params(1) * x) ./ (1 + params(2) * x + params(3) * x.^2);

initial_guess = [1, 1, 1];

params = lsqcurvefit(model, initial_guess, x_data, y_data);

a = params(1);
b = params(2);
c = params(3);

x_fit = linspace(0, 1, 100);
y_fit = model(params, x_fit);

figure;
plot(x_data, y_data, 'ro', 'DisplayName', 'Tabulated Data');
hold on;
plot(x_fit, y_fit, 'b-', 'DisplayName', 'Fitted Curve');
xlabel('x (Mole fraction in liquid)');
ylabel('y (Mole fraction in vapor)');
title('Methanol-Water VLE Data Fitting');
legend('Location', 'best');
grid on;

z_F = 0.45;
x_D = 0.97;
x_W = 0.02;
x_S = 0.70;
F = 500;
S = 50;

syms D W
eq1 = D + W + S == F;
eq2 = D * x_D + W * x_W + S * x_S == F * z_F;
sol = solve([eq1, eq2], [D, W]);

D = double(sol.D);
W = double(sol.W);

disp(['Distillate (D) = ', num2str(D), ' kmol/hr']);
disp(['Bottom (W) = ', num2str(W), ' kmol/hr']);

q = 0.8;
fplot(@(x) q*x./(q-1) - z_F/(q-1), [0.3829, 0.45], 'g-', 'DisplayName', 'Feed Line');

eqns_1 = @(x) [x(2) - a*x(1)./(1 + b*x(1) + c*x(1).^2); q*x(1)./(q-1) - z_F/(q-1) - x(2)];
point1 = fsolve(eqns_1, [0, 0]);

R = (x_D - point1(2)) / (point1(2) - x_S);
Lo = R * D;

eqns_2 = @(x) [(Lo - S)*x(1)./(Lo + D) + (S*x_S + D*x_D)/(Lo + D) - x(2); q*x(1)./(q-1) - z_F/(q-1) - x(2)];
point2 = fsolve(eqns_2, [0, 0]);

feed_line = @(x) q * x / (q - 1) - z_F / (q - 1);

side_stream_line = @(x) (S * x_S + D * x_D) / (Lo + D) - (Lo - S) * x / (Lo + D);

op_line_sec1 = @(x) R * x / (R + 1) + x_D / (R + 1);
op_line_sec2 = @(x) (Lo - S) * x / (Lo + D) + (S * x_S + D * x_D) / (Lo + D);
op_line_sec3 = @(x) 1.3667 * x - 0.0073;

max_trays = 20;
x_vals = x_D;
y_vals = x_D;
tray_lines_x = [];
tray_lines_y = [];

for tray = 1:max_trays
    y_next = op_line_sec1(x_vals(end));
    if x_vals(end) <= x_S
        y_next = op_line_sec2(x_vals(end));
    end
    if x_vals(end) <= z_F 
        y_next = op_line_sec3(x_vals(end));
    end
    tray_lines_x = [tray_lines_x, x_vals(end), x_vals(end)];
    tray_lines_y = [tray_lines_y, y_vals(end), y_next];
    y_vals = [y_vals, y_next];
    x_next = interp1(y_fit, x_fit, y_next, 'linear', 'extrap');
    tray_lines_x = [tray_lines_x, x_next];
    tray_lines_y = [tray_lines_y, y_next];
    x_vals = [x_vals, x_next];

    if x_next <= x_W
        break;
    end
end

figure;
hold on;

plot(x_fit, y_fit, 'b-', 'DisplayName', 'Equilibrium Curve');

plot(x_D, x_D, 'ro', 'MarkerSize', 8, 'DisplayName', 'Distillate (D)');
plot(x_W, x_W, 'go', 'MarkerSize', 8, 'DisplayName', 'Bottom (W)');
plot(x_S, x_S, 'mo', 'MarkerSize', 8, 'DisplayName', 'Side-stream (S)');
plot(z_F, z_F, 'co', 'MarkerSize', 8, 'DisplayName', 'Feed (F)');

fplot(feed_line, [x_W, x_D], 'g--', 'DisplayName', 'Feed Line');

fplot(side_stream_line, [point2(1), x_S], 'm--', 'DisplayName', 'Side-stream Line');

fplot(op_line_sec1, [x_S, x_D], 'r-', 'DisplayName', 'Section I');
fplot(op_line_sec2, [point2(1), x_S], 'y-', 'DisplayName', 'Section II');
fplot(op_line_sec3, [x_W, point2(1)], 'k-', 'DisplayName', 'Section III');

stairs(tray_lines_x, tray_lines_y, 'c-', 'DisplayName', 'McCabe-Thiele Trays');

xlabel('x (Mole fraction in liquid)');
ylabel('y (Mole fraction in vapor)');
title('Figure 2');
legend('Location', 'best');
grid on;

disp(['Number of trays = ', num2str(length(x_vals) - 1)]);
disp(['Feed tray located at tray = ', num2str(find(x_vals <= z_F, 1, 'first'))]);
disp(['Side-stream tray located at tray = ', num2str(find(x_vals <= x_S, 1, 'first'))]);
