clear all;
clc;

% Given data
x = [0 0.02 0.04 0.06 0.08 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 0.95 1.0];
y = [0 0.134 0.23 0.304 0.365 0.418 0.579 0.665 0.729 0.779 0.825 0.87 0.915 0.958 0.979 1];

Func = @(params, xdata) (params(1).*xdata) ./ (1 + params(2).*xdata + params(3).*xdata.^2);

% Initial guess for parameters [a, b, c]
params0 = [1, 1, 1];

params = fminsearch(@(params) sum((y - Func(params, x)).^2), params0);

a = params(1);
b = params(2);
c = params(3);

% Generate fitted curve
y_fit = Func([a, b, c], x);

% Plot data and fitted curve
figure;
plot(x, y, 'r.', 'DisplayName', 'Tabulated Data'); hold on;
plot(x, y_fit, 'b-','DisplayName', 'Fitted Curve');
title(sprintf('Fitted Equilibrium Curve: y = a*x/(1 + b*x + c*x^2)\n a=%.4f, b=%.4f, c=%.4f', a, b, c));
xlabel('x (mole fraction of ethanol)');
ylabel('y (mole fraction of ethanol in vapor)');
legend('show');
grid on;
