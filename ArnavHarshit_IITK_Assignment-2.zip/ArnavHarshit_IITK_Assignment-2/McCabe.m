function [nt, X_points, Y_points] = McCabe(xd, xb, a, b, c)

    X = xd;
    Y = xd;

    % Store points for plotting
    X_points = X;
    Y_points = Y;

    nt = -1;
    max_iterations = 100;
    equilibrium_curve = @(X) a*X ./ (1 + b*X + c*X.^2);
    operating_line = @(X) X;
    while X >= xb && nt < max_iterations
        Xold = X;
        Yold = Y;
        
        % Calculate X based on the operating line (45-degree line)
        X = operating_line(Y);

        % Calculate Y based on the equilibrium curve
        Y = equilibrium_curve(X);

        nt = nt + 1;
        
        X_points = [X_points, X];
        Y_points = [Y_points, Y];
        
        plot([Xold X], [Yold Yold], 'b'); % Equilibrium curve
        plot([X X], [Yold Y], 'r'); % Operating line
    end
    if length(X_points) > 1
        nt = round(nt + (X_points(end-1) - xb) / (Y_points(end-1) - Y), 2);
    end
end
