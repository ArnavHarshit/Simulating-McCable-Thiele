clear all;
clc;
% parameters a,b,c we got from previous part
a=7.9672;
b=9.4108;
c=-2.4383;

% Define the equilibrium curve function
equilibrium_curve = @(X) a*X ./ (1 + b*X + c*X.^2);

% Define the operating line (45-degree line)
operating_line = @(X) X;

% Define distillate and bottom compositions
xd = 0.95;
xb_1 = 0.08;
xb_2 = 0.04;

% Create figure for both cases
figure;
hold on;
title(['McCabe-Thiele Construction (x_b = ', num2str(xb_1), ')']);
xlabel('Mole Fraction of Ethanol in Liquid (X)');
ylabel('Mole Fraction of Ethanol in Vapor (Y)');
% Plot the equilibrium curve
X_vals = linspace(0, 1, 100);
Y_vals = equilibrium_curve(X_vals);
plot(X_vals, Y_vals, 'k'); % Equilibrium curve
[nt_1, X_points_1, Y_points_1] = McCabe(xd, xb_1, a, b, c);
legend('Equilibrium curve', 'Operating line', 'Tray Construction',Location='east');

figure;
hold on;
title(['McCabe-Thiele Construction (x_b = ', num2str(xb_2), ')']);
xlabel('Mole Fraction of Ethanol in Liquid (X)');
ylabel('Mole Fraction of Ethanol in Vapor (Y)');
% Plot the equilibrium curve
Y_vals = equilibrium_curve(X_vals);
plot(X_vals, Y_vals, 'k'); % Equilibrium curve
[nt_2, X_points_2, Y_points_2] = McCabe(xd, xb_2, a, b, c);
legend('Equilibrium curve', 'Operating line', 'Tray Construction',Location='east');
